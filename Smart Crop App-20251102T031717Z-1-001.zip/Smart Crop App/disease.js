// Minimal stub for disease.js
// All original, large disease data has been removed to prevent parse errors.
// The active implementation is in /disease_clean.js
window.DISEASE_JS_LEGACY_REMOVED = true;
        
